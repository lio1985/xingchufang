# 项目迁移指南 - 全新 Coze 项目设置

## 目标
彻底摆脱当前项目缓存的旧数据库 schema / 旧数据库绑定状态，使用全新的 Supabase 项目重新开始。

---

## 第一步：在 Coze 中创建新项目

1. 登录 Coze 平台
2. 创建一个全新的编程项目
3. 选择 "Taro" 模板初始化项目

---

## 第二步：从当前项目复制需要的文件

### 需要复制到新项目的文件清单：

#### 根目录文件（保留）
```
✅ .coze
✅ .cozeproj/
✅ .env.example
✅ .gitignore
✅ .npmrc
✅ babel.config.js
✅ design_guidelines.md
✅ eslint.config.mjs
✅ package.json
✅ pnpm-lock.yaml
✅ pnpm-workspace.yaml
✅ project.config.json
✅ stylelint.config.mjs
✅ tsconfig.json
```

#### 源文件目录（完整复制）
```
✅ assets/
✅ config/
✅ database-setup/
✅ docs/
✅ key/
✅ public/
✅ scripts/
✅ server/
✅ src/
✅ tests/
✅ types/
```

#### Markdown 文档（可选复制）
```
✅ README.md
✅ SUMMARY.md
✅ Coze FaaS 部署指南.md
✅ RECYCLE_MANAGEMENT_SETUP.md
✅ 审核说明.md
✅ 微信小程序开发环境配置指南.md
```

---

## 第三步：**不要复制**的文件（重要！）
```
❌ node_modules/
❌ dist/
❌ dist-web/
❌ dist-weapp/
❌ server/dist/
❌ .swc/
❌ .temp/
❌ .env.development
❌ .env.local
❌ .env（如果存在）
```

---

## 第四步：在新项目中配置 Supabase 环境变量

在新项目中创建以下环境变量文件：

### `.env.local` 配置（生产环境）
```env
# ===================================
# 数据库配置 (必填)
# ===================================
COZE_SUPABASE_URL=https://bopwfsdkhiunxmhkzebk.supabase.co
COZE_SUPABASE_ANON_KEY=sb_publishable_wY9mCejwhnXGo0oJPjrd-g_s34Mzbbh
COZE_SUPABASE_SERVICE_ROLE_KEY=sb_secret_l2-eUUl26Pclvlo34pXCqg_s6I1Z0tb

# ===================================
# JWT认证配置 (必填 - 生产环境)
# ===================================
JWT_SECRET=7ljv7q9qB19xPkWR7gpQM0cZ2dHHvDD3B2Res7BN/PtMxrcJYfNsvNlMf+21XsF94399tGLVYDNIDcAPiEECJQ==
JWT_EXPIRES_IN=7d

# ===================================
# 应用配置 (必填)
# ===================================
APP_NAME=星厨房内容创作助手
NODE_ENV=production

# ===================================
# 微信小程序配置 (必填)
# ===================================
TARO_APP_WEAPP_APPID=wx073136fc152cedd9
WECHAT_APP_SECRET=c52e1ac69731740bfc5a423c5013a297

# ===================================
# 超级管理员配置 (可选)
# ===================================
SUPER_ADMIN_OPENID=mock_openid_test123

# ===================================
# 生产环境域名 (必填)
# ===================================
PROJECT_DOMAIN=http://9.129.186.33:5000

# ===================================
# 对象存储配置 (必填 - 数据导出功能)
# ===================================
COZE_S3_ENDPOINT=https://your-s3-endpoint.com
COZE_S3_ACCESS_KEY_ID=your-access-key-id
COZE_S3_SECRET_ACCESS_KEY=your-secret-access-key
COZE_S3_BUCKET=your-bucket-name
COZE_S3_REGION=your-region

# ===================================
# 可选配置
# ===================================
SERVER_PORT=3000
WEB_PORT=5000
API_TIMEOUT=30000
```

### `.env.development` 配置（开发环境）
```env
# 开发环境配置 - 用于微信小程序本地测试

# ===================================
# 数据库配置
# ===================================
COZE_SUPABASE_URL=https://bopwfsdkhiunxmhkzebk.supabase.co
COZE_SUPABASE_ANON_KEY=sb_publishable_wY9mCejwhnXGo0oJPjrd-g_s34Mzbbh

# ===================================
# JWT认证配置
# ===================================
JWT_SECRET=7ljv7q9qB19xPkWR7gpQM0cZ2dHHvDD3B2Res7BN/PtMxrcJYfNsvNlMf+21XsF94399tGLVYDNIDcAPiEECJQ==
JWT_EXPIRES_IN=7d

# ===================================
# 应用配置
# ===================================
APP_NAME=星厨房内容创作助手
NODE_ENV=development

# ===================================
# 微信小程序配置
# ===================================
TARO_APP_WEAPP_APPID=wx073136fc152cedd9
WECHAT_APP_SECRET=c52e1ac69731740bfc5a423c5013a297

# ===================================
# 超级管理员配置
# ===================================
SUPER_ADMIN_OPENID=mock_openid_test123

# ===================================
# 开发环境域名配置
# ===================================
PROJECT_DOMAIN=http://9.129.186.33:5000

# ===================================
# 对象存储配置
# ===================================
COZE_S3_ENDPOINT=https://your-s3-endpoint.com
COZE_S3_ACCESS_KEY_ID=your-access-key-id
COZE_S3_SECRET_ACCESS_KEY=your-secret-access-key
COZE_S3_BUCKET=your-bucket-name
COZE_S3_REGION=your-region

# ===================================
# 开发环境端口配置
# ===================================
SERVER_PORT=3000
WEB_PORT=5000
API_TIMEOUT=30000
```

---

## 第五步：在 Supabase 中手动初始化数据库

### 重要：这是唯一的数据库 Schema 来源

1. 登录 Supabase 控制台
2. 进入新项目的 SQL Editor
3. 复制 `database-setup/init.sql` 文件的完整内容
4. 在 SQL Editor 中执行该脚本
5. 确认所有表都成功创建

**注意：

- 确保使用 `database-setup/init.sql` 是**唯一**的数据库 schema 源
- 不要使用 Coze FaaS 的自动迁移功能
- 完全手动执行 SQL 脚本

---

## 第六步：在新项目中安装依赖并构建

在新项目中执行：

```bash
# 安装依赖
pnpm install

# 类型检查
pnpm validate

# 构建项目
pnpm build
```

---

## 第七步：部署到 Coze FaaS

1. 在新项目中点击部署
2. 确保 Coze FaaS 会检测到 `database-setup/init.sql` 作为唯一的 schema 源
3. 但**不要**使用自动迁移，完全依赖手动执行的 SQL

---

## 关键检查清单

### 迁移前检查：
- [ ] 确认已在 Supabase 中创建了全新的项目
- [ ] 确认新 Supabase 项目 URL、Anon Key、Service Role Key 已更新
- [ ] 确认没有复制旧的 `.env.local` 和 `.env.development`
- [ ] 确认没有复制 `node_modules/` 和 `dist/` 目录

### 迁移后检查：
- [ ] 确认只保留 `database-setup/init.sql` 是唯一的数据库 schema 源
- [ ] 确认已在 Supabase SQL Editor 中手动执行了初始化脚本
- [ ] 确认环境变量中的 Supabase 配置是新的项目
- [ ] 确认可以正常构建和部署

---

## 为什么这样做？

### 1. 彻底摆脱旧项目的缓存
- 旧项目可能在 Coze 平台内部缓存了旧的数据库 schema 信息
- 旧项目可能与旧的 Supabase 项目有绑定关系
- 全新项目 = 全新开始，无历史包袱

### 2. 确保唯一的 Schema 源
- 只保留 `database-setup/init.sql` 作为唯一的 schema 定义
- 避免 Coze 平台从其他地方读取旧的 schema 定义
- 完全手动控制数据库初始化

### 3. 全新的 Supabase 项目
- 全新的数据库，全新的开始
- 没有旧数据，没有冲突

---

## 故障排除

### 如果还是报错 "operator does not exist: text = uuid"

1. 确认在 Supabase SQL Editor 中手动执行了 `database-setup/init.sql`
2. 确认没有使用 Coze FaaS 的自动迁移功能
3. 确认环境变量中的 Supabase 配置是新的项目

### 如果构建失败

1. 删除 `node_modules/` 重新安装
2. 运行 `pnpm install`
3. 运行 `pnpm validate` 检查类型错误
4. 运行 `pnpm build` 构建项目
