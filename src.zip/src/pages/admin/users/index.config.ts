export default typeof definePageConfig === 'function'
  ? definePageConfig({
      navigationBarTitleText: '用户管理',
      navigationBarBackgroundColor: '#0f172a',
      navigationBarTextStyle: 'white'
    })
  : {
      navigationBarTitleText: '用户管理',
      navigationBarBackgroundColor: '#0f172a',
      navigationBarTextStyle: 'white'
    }
