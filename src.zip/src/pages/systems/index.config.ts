export default definePageConfig({
  navigationBarTitleText: '工具箱'
})
